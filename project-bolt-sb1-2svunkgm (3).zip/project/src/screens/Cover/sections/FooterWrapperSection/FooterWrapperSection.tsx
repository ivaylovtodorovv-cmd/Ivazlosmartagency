import React from "react";

export const FooterWrapperSection = (): JSX.Element => {
  return (
    <footer className="px-[33.44px] py-[10.03px] flex items-center justify-between w-full bg-slate-900">
      <div className="inline-flex items-center gap-[6.69px]">
        <img
          className="w-[16.72px] h-[16.72px]"
          alt="Isolation mode"
          src="/isolation-mode.svg"
        />

        <div className="[font-family:'Angry-Regular',Helvetica] font-normal text-white text-[10px] tracking-[0] leading-[11.0px] whitespace-nowrap">
          Conscellence
        </div>
      </div>

      <div className="[font-family:'Montserrat',Helvetica] font-medium text-white text-[6.7px] tracking-[0] leading-[9.4px] whitespace-nowrap">
        All rights reserved © 2024 Cons Consulting.&nbsp;&nbsp;Privacy Policy |
        Terms of Service
      </div>
    </footer>
  );
};
