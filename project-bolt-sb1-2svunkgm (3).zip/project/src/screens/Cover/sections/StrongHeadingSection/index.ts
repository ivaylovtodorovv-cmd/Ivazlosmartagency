export { StrongHeadingSection } from "./StrongHeadingSection";
