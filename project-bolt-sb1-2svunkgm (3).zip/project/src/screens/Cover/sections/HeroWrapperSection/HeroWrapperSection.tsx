import { ArrowUpRightIcon, MailIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";

const navItems = [
  { label: "SERVICES" },
  { label: "ABOUT US" },
  { label: "CONTACT US" },
];

export const HeroWrapperSection = (): JSX.Element => {
  return (
    <section className="flex flex-col items-start relative w-full rounded-[0px_0px_23.41px_23.41px] [background:url(../hero-section-1.png)_50%_50%_/_cover]">
      <nav className="px-[33.44px] py-[6.69px] flex items-center justify-between relative w-full">
        <div className="gap-[5.01px] inline-flex items-center">
          <img
            className="relative w-[12.53px] h-[12.53px]"
            alt="Conscellence logo"
            src="/isolation-mode.svg"
          />
          <div className="relative items-center w-fit [font-family:'Angry-Regular',Helvetica] font-normal text-slate-900 text-[7.5px] tracking-[0] leading-[8.3px] whitespace-nowrap flex justify-center">
            Conscellence
          </div>
        </div>

        <div className="inline-flex items-center">
          {navItems.map((item, index) => (
            <Button
              key={index}
              variant="ghost"
              className="h-[23.41px] gap-[3.34px] px-[13.38px] py-[6.69px] rounded-[20.07px] font-button-m font-[number:var(--button-m-font-weight)] text-slate-900 text-[length:var(--button-m-font-size)] tracking-[var(--button-m-letter-spacing)] leading-[var(--button-m-line-height)] [font-style:var(--button-m-font-style)] hover:bg-transparent"
            >
              {item.label}
            </Button>
          ))}
        </div>

        <Button
          variant="outline"
          className="h-auto w-[84.45px] gap-[3.34px] px-[13.38px] py-[6.69px] rounded-[20.07px] border-[0.42px] border-solid border-[#0019ff] font-button-l font-[number:var(--button-l-font-weight)] text-[#0019ff] text-[length:var(--button-l-font-size)] tracking-[var(--button-l-letter-spacing)] leading-[var(--button-l-line-height)] [font-style:var(--button-l-font-style)] hover:bg-[#0019ff] hover:text-white"
        >
          (987)-749-5403
        </Button>
      </nav>

      <div className="flex flex-col items-start gap-[20.07px] pt-[50.17px] pb-[66.89px] px-[50.17px] relative w-full">
        <div className="max-w-[301px] gap-[6.69px] flex flex-col items-start w-full">
          <h1 className="relative items-center self-stretch mt-[-0.42px] [font-family:'Unbounded',Helvetica] font-normal text-transparent text-[23.4px] tracking-[0] leading-[23.4px] flex justify-center">
            <span className="text-[#0019ff] leading-[25.8px]">
              Unlock Your Potential
            </span>
            <span className="text-slate-900 leading-[25.8px]">
              {" "}
              with Strategic Consulting
            </span>
          </h1>

          <p className="relative flex items-center justify-center self-stretch [font-family:'Montserrat',Helvetica] font-medium text-slate-600 text-[8.4px] tracking-[0] leading-[12.5px]">
            Guiding Your Success Journey Through Expertise and Innovation
          </p>
        </div>

        <div className="gap-[3.34px] inline-flex items-start">
          <div className="w-[133.78px] h-[23.41px] gap-[6.69px] px-[10.03px] py-[6.69px] rounded-[16.72px] flex items-center relative bg-white">
            <MailIcon className="w-[10.03px] h-[10.03px] text-slate-500" />
            <Input
              type="email"
              placeholder="Enter your email to get started"
              className="h-auto border-0 p-0 flex-1 [font-family:'Montserrat',Helvetica] font-medium text-slate-500 text-[5px] tracking-[0] leading-[6.0px] placeholder:text-slate-500 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>

          <Button className="h-auto inline-flex items-center gap-[6.69px] pl-[10.03px] pr-[3.34px] py-[2.51px] bg-[#0019ff] rounded-[33.44px] hover:bg-[#0019ff]/90">
            <span className="font-button-l font-[number:var(--button-l-font-weight)] text-white text-[length:var(--button-l-font-size)] tracking-[var(--button-l-letter-spacing)] leading-[var(--button-l-line-height)] whitespace-nowrap [font-style:var(--button-l-font-style)]">
              GET STARTED
            </span>
            <div className="gap-[3.34px] p-[5.02px] rounded-[33.44px] inline-flex flex-col items-start bg-slate-50">
              <ArrowUpRightIcon className="w-[8.36px] h-[8.36px] text-[#0019ff]" />
            </div>
          </Button>
        </div>
      </div>

      <img
        className="absolute right-[567px] bottom-[-1239px] w-[232px] h-[348px] object-cover"
        alt="Decorative element"
        src="/2-removebg-1.png"
      />
    </section>
  );
};
