import { ArrowRightIcon, ArrowUpRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";

const services = [
  {
    title: "Customized Strategy Development",
    description:
      "Tailor-made strategies to address your unique business challenges and opportunities, ensuring sustainable growth and competitive advantage.",
  },
  {
    title: "Operational Efficiency Optimization",
    description:
      "Streamline your processes and improve efficiency with our expert guidance, helping you save time and resources.",
  },
  {
    title: "Market Analysis and Insights",
    description:
      "Gain valuable market insights and stay ahead of the competition with our comprehensive analysis and data-driven recommendations.",
  },
  {
    title: "Leadership and Team Building",
    description:
      "Enhance your leadership capabilities and foster a high-performing team through our specialized training and development programs.",
  },
];

export const FrameSection = (): JSX.Element => {
  return (
    <section className="gap-[4.18px] px-[10.03px] py-0 flex flex-col items-start w-full">
      <div className="flex-col rounded-[23.41px] overflow-hidden border-l-[0.42px] border-l-white flex items-start w-full">
        {services.map((service, index) => (
          <div
            key={index}
            className={`gap-[33.44px] px-[33.44px] py-[23.41px] w-full bg-slate-900 flex items-start ${
              index < services.length - 1
                ? "border-b-[0.42px] border-b-white"
                : ""
            }`}
          >
            <ArrowRightIcon className="w-[10.03px] h-[10.03px] text-white flex-shrink-0" />

            <div className="flex items-start gap-[33.44px] flex-1">
              <h3 className="items-center flex-1 [font-family:'Unbounded',Helvetica] font-normal text-white text-[16.7px] tracking-[0] leading-[20.1px] flex justify-center">
                {service.title}
              </h3>

              <p className="items-center flex-1 [font-family:'Montserrat',Helvetica] font-medium text-white text-[7.5px] tracking-[0] leading-[10.5px] flex justify-center">
                {service.description}
              </p>
            </div>
          </div>
        ))}

        <div className="flex items-center gap-[33.44px] pl-[76.92px] pr-[33.44px] py-[16.72px] w-full bg-[#0019ff] shadow-[8.36px_8.36px_16.72px_#70818833]">
          <div className="flex items-center justify-center flex-1 [font-family:'Unbounded',Helvetica] font-normal text-white text-[16.7px] tracking-[0] leading-[20.1px]">
            Free consultation
          </div>

          <div className="flex items-center gap-[10.03px] flex-1">
            <Button
              variant="outline"
              className="h-auto inline-flex items-center justify-center gap-[3.34px] pl-[13.38px] pr-[10.03px] py-[6.69px] rounded-[20.07px] border-[0.42px] border-slate-50 bg-transparent hover:bg-white/10"
            >
              <span className="font-button-l font-[number:var(--button-l-font-weight)] text-slate-50 text-[length:var(--button-l-font-size)] tracking-[var(--button-l-letter-spacing)] leading-[var(--button-l-line-height)] whitespace-nowrap [font-style:var(--button-l-font-style)]">
                SCHEDULE A FREE CALL
              </span>
              <ArrowUpRightIcon className="w-[10.03px] h-[10.03px]" />
            </Button>

            <div className="inline-flex items-center gap-[16.72px]">
              <span className="[font-family:'Poppins',Helvetica] font-normal italic text-white text-[6.7px] tracking-[0] leading-[normal] line-through">
                worth 200 USD
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
