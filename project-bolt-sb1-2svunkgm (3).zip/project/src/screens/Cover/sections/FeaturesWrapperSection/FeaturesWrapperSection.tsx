import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

const features = [
  {
    number: "01",
    title: "Stagnant Growth?",
    description:
      "Unleash your business's true potential by identifying growth barriers and implementing strategic solutions.",
  },
  {
    number: "02",
    title: "Operational Inefficiencies?",
    description:
      "Streamline your operations with our consulting expertise, optimizing processes for enhanced efficiency.",
  },
  {
    number: "03",
    title: "Market Challenges?",
    description:
      "Overcome market challenges with tailored strategies designed to position your business for success.",
  },
];

export const FeaturesWrapperSection = (): JSX.Element => {
  return (
    <section className="flex flex-col items-center gap-[26.76px] p-[50.17px] w-full">
      <h2 className="[font-family:'Unbounded',Helvetica] font-normal text-slate-900 text-[16.7px] text-center tracking-[0] leading-[20.1px] whitespace-nowrap">
        Are You Running Into These Problems?
      </h2>

      <div className="flex items-start gap-[3.34px] w-full">
        {features.map((feature, index) => (
          <Card
            key={index}
            className="flex-1 rounded-[16.72px] border-[0.42px] border-slate-500"
          >
            <CardContent className="flex flex-col items-start gap-[6.69px] p-[16.72px]">
              <div className="w-[16.72px] text-[8.4px] leading-[11.7px] [font-family:'Angry-Regular',Helvetica] font-normal text-[#0019ff] tracking-[0]">
                {feature.number}
              </div>

              <h3 className="self-stretch [font-family:'Montserrat',Helvetica] font-bold text-slate-800 text-[10px] tracking-[0] leading-[15.0px] text-center">
                {feature.title}
              </h3>

              <p className="self-stretch [font-family:'Montserrat',Helvetica] font-medium text-slate-600 text-[7.5px] tracking-[0] leading-[10.5px] text-center">
                {feature.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
