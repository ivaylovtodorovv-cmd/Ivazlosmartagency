import React from "react";
import { Facebook, Twitter, Instagram, Linkedin, Youtube } from "lucide-react";

export const FooterSection = (): JSX.Element => {
  return (
    <footer className="py-16 md:py-20 w-full bg-[#1a3a52] overflow-x-hidden border-t-2 border-[#d4af37]">
      <div className="container mx-auto max-w-7xl px-6 md:px-16">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 w-full">
          <div className="flex flex-col items-center md:items-start gap-6">
            <div className="inline-flex items-center gap-3">
              <img src="/brain.png" alt="Logo" className="w-10 h-10 object-contain" />
              <div className="font-serif font-bold text-[#d4af37] text-xl tracking-tight whitespace-nowrap">
                Ivaylo's Smart Agency
              </div>
            </div>

            <div className="flex gap-3">
              <a href="#" className="group">
                <div className="bg-[#1a3a52]/60 hover:bg-gradient-to-br hover:from-[#d4af37] hover:to-[#f0d77c] rounded-xl p-3 transition-all duration-500 hover:scale-110 hover:shadow-lg hover:shadow-[#d4af37]/50">
                  <Facebook className="w-5 h-5 text-white" />
                </div>
              </a>
              <a href="#" className="group">
                <div className="bg-[#1a3a52]/60 hover:bg-gradient-to-br hover:from-[#d4af37] hover:to-[#f0d77c] rounded-xl p-3 transition-all duration-500 hover:scale-110 hover:shadow-lg hover:shadow-[#d4af37]/50">
                  <Twitter className="w-5 h-5 text-white" />
                </div>
              </a>
              <a href="#" className="group">
                <div className="bg-[#1a3a52]/60 hover:bg-gradient-to-br hover:from-[#d4af37] hover:to-[#f0d77c] rounded-xl p-3 transition-all duration-500 hover:scale-110 hover:shadow-lg hover:shadow-[#d4af37]/50">
                  <Instagram className="w-5 h-5 text-white" />
                </div>
              </a>
              <a href="#" className="group">
                <div className="bg-[#1a3a52]/60 hover:bg-gradient-to-br hover:from-[#d4af37] hover:to-[#f0d77c] rounded-xl p-3 transition-all duration-500 hover:scale-110 hover:shadow-lg hover:shadow-[#d4af37]/50">
                  <Linkedin className="w-5 h-5 text-white" />
                </div>
              </a>
              <a href="#" className="group">
                <div className="bg-[#1a3a52]/60 hover:bg-gradient-to-br hover:from-[#d4af37] hover:to-[#f0d77c] rounded-xl p-3 transition-all duration-500 hover:scale-110 hover:shadow-lg hover:shadow-[#d4af37]/50">
                  <Youtube className="w-5 h-5 text-white" />
                </div>
              </a>
            </div>
          </div>

          <div className="font-sans font-normal text-white/80 text-sm tracking-normal leading-relaxed text-center md:text-right">
            Всички права запазени © 2024 Ivaylo's Smart Agency.&nbsp;&nbsp;Политика за поверителност |
            Условия за ползване
          </div>
        </div>
      </div>
    </footer>
  );
};
