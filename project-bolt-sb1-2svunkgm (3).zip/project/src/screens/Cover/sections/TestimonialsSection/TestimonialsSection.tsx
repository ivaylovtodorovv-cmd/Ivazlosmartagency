import React, { useState } from "react";
import { Card, CardContent } from "../../../../components/ui/card";

const renderFormattedText = (text: string) => {
  const lines = text.split('\n');
  return lines.map((line, index) => {
    const isExample = line.trim().startsWith('>');
    const isBold = line.includes('**');

    if (isExample) {
      const cleanLine = line.replace(/^>\s*/, '');
      const parts = cleanLine.split('*');
      return (
        <p key={index} className="text-white/70 text-base md:text-lg leading-[1.5] mb-2 italic pl-4 border-l-2 border-[#d4af37]/50">
          {parts.map((part, i) => (
            i % 2 === 1 ? <em key={i}>{part}</em> : part
          ))}
        </p>
      );
    }

    if (isBold) {
      const parts = line.split('**');
      return (
        <p key={index} className="text-white text-base md:text-lg leading-[1.5] mb-3">
          {parts.map((part, i) => (
            i % 2 === 1 ? <strong key={i} className="font-bold text-white">{part}</strong> : part
          ))}
        </p>
      );
    }

    if (line.trim() === '') {
      return <div key={index} className="h-2" />;
    }

    return (
      <p key={index} className="text-white text-base md:text-lg leading-[1.5] mb-3">
        {line}
      </p>
    );
  });
};

const missionContent = [
  {
    title: "Нашата мисия",
    content: `Нашата мисия е да направим изкуствения интелект **достъпен и полезен за всеки бизнес**, независимо от мащаба му.
Вярваме, че технологиите трябва **да работят за хората**, а не обратното.
Затова помагаме на малките и средни компании да открият нови възможности за растеж, като превръщаме сложното в практично и разбираемо.
> *Вдъхновяваме се от идеята, че всяка добра стратегия започва с човека, а не с машината.*`,
  },
  {
    title: "Нашето вдъхновение",
    content: `Вдъхновяваме се от идеята, че технологията трябва да прави живота по-лесен, а не по-сложен.
Виждаме бизнес собственици, които работят с остарели процеси, губят време и възможности – и знаем, че има по-добър начин.
Вярваме в силата на автоматизацията и изкуствения интелект да **освобождават ресурси** и да дават повече свобода за креативност и стратегическо мислене.`,
  },
  {
    title: "Нашата визия",
    content: `Нашата визия е да станем **доверен технологичен партньор** за стотици малки и средни бизнеси в България и Европа.
Искаме всеки бизнес да има възможност да използва силата на AI, без да е необходимо да има собствен IT отдел или огромен бюджет.
Виждаме бъдеще, в което технологиите са **интуитивни, достъпни и адаптирани** към нуждите на всеки.`,
  },
];

export const TestimonialsSection = (): JSX.Element => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  return (
    <section id="misia" className="relative w-full bg-[#1a3a52] py-24 md:py-40 overflow-x-hidden">
      <div className="container mx-auto max-w-7xl px-6 md:px-16 relative z-10">
        <div className="flex flex-col items-center gap-12 md:gap-16 relative">
          <div className="relative w-full max-w-4xl text-center mb-4">
            <h2 className="font-serif font-bold text-4xl md:text-6xl tracking-tight leading-tight mb-4">
              <span className="text-[#d4af37]">Нашата мисия и вдъхновение</span>
            </h2>
            <p className="text-lg md:text-xl text-white font-semibold font-sans leading-relaxed max-w-4xl mx-auto">
              Вярваме, че изкуственият интелект има смисъл само когато помага на хората да правят бизнеса си по-умен, по-ефективен и по-човешки.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full">
            {missionContent.map((item, index) => (
              <Card
                key={index}
                onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
                className="bg-[#1a3a52]/60 backdrop-blur-sm rounded-[30px] border-2 border-[#d4af37]/30 shadow-xl hover:border-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/30 hover:-translate-y-2 h-full flex flex-col transition-all duration-500 ease-in-out opacity-0 animate-fade-in group relative overflow-hidden cursor-pointer"
              >
                <CardContent className="flex flex-col items-start gap-6 p-6 md:p-10 flex-1 relative z-10">
                  <h3 className="inline-block text-xl md:text-3xl font-serif font-bold text-[#1a3a52] bg-gradient-to-r from-[#d4af37] to-[#f0d77c] px-4 md:px-6 py-2 md:py-3 rounded-2xl shadow-xl hover:shadow-[#d4af37]/60 transition-all duration-300">
                    {item.title}
                  </h3>
                  {expandedIndex === index && (
                    <div className="font-sans animate-in slide-in-from-top-2 fade-in duration-300">
                      {renderFormattedText(item.content)}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
