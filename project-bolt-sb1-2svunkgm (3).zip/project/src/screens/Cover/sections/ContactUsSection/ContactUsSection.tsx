import React from "react";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";
import { Phone, Mail, MapPin } from "lucide-react";

const contactInfo = [
  {
    icon: Phone,
    text: "0892 337 322",
    href: "tel:+359892337322",
  },
  {
    icon: Mail,
    text: "ivaylosmartagency@gmail.com",
    href: "mailto:ivaylosmartagency@gmail.com",
  },
  {
    icon: MapPin,
    text: "София, България",
    href: null,
  },
];

export const ContactUsSection = (): JSX.Element => {
  return (
    <section className="py-24 md:py-40 w-full overflow-x-hidden relative bg-[#1a3a52]">
      <div className="container mx-auto max-w-7xl px-6 md:px-16 relative z-10">
        <div className="flex flex-col lg:flex-row items-stretch gap-8 md:gap-16">
          <div className="flex flex-col items-start justify-center gap-8 md:gap-12 flex-1 bg-[#1a3a52]/40 backdrop-blur-sm p-8 md:p-14 rounded-3xl shadow-2xl border-2 border-[#d4af37]/30 hover:border-[#d4af37] hover:shadow-[#d4af37]/30 transition-all duration-500 hover:-translate-y-2">
            <div className="flex flex-col items-center gap-6 md:gap-8 w-full">
              <div className="flex flex-col items-center justify-center w-full text-center">
                <h2 className="w-full font-serif font-bold text-white text-4xl md:text-7xl tracking-tight leading-tight">
                  СВЪРЖЕТЕ СЕ
                </h2>
                <h2 className="w-full font-serif font-bold text-[#d4af37] text-4xl md:text-7xl tracking-tight leading-tight">
                  С НАС ДНЕС
                </h2>
              </div>

              <div className="flex items-center justify-center w-full">
                <p className="font-sans font-normal text-white/90 text-lg md:text-2xl tracking-normal leading-relaxed text-center max-w-2xl">
                  Искате ли да разберете как AI може да помогне конкретно на вашия бизнес? Резервирайте безплатна 30-минутна консултация с наш експерт. Без ангажимент – само стойност.
                </p>
              </div>
            </div>

          </div>

          <div className="flex flex-col w-full lg:w-[450px] items-start gap-8 md:gap-12 bg-[#1a3a52]/40 backdrop-blur-sm p-8 md:p-12 rounded-3xl shadow-2xl border-2 border-[#d4af37]/30 hover:border-[#d4af37] hover:shadow-[#d4af37]/30 transition-all duration-500 hover:-translate-y-2">
            <div className="flex flex-col items-center gap-6 w-full">
              <div className="flex items-center justify-center w-full font-serif font-bold text-white text-xl md:text-2xl tracking-wide text-center">
                Изискайте безплатна консултация
              </div>

              <Button className="w-full inline-flex items-center justify-center gap-4 px-12 py-6 bg-gradient-to-r from-[#d4af37] to-[#f0d77c] rounded-[30px] hover:from-[#f0d77c] hover:to-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/60 transition-all duration-300 hover:scale-105 h-auto shadow-xl">
                <span className="font-sans font-bold text-[#1a3a52] text-lg tracking-wide whitespace-nowrap">
                  ИЗИСКАЙ КОНСУЛТАЦИЯ
                </span>
              </Button>
            </div>

            <div className="inline-flex flex-col items-start justify-center gap-4 md:gap-[10.58px]">
              {contactInfo.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <div key={index} className="inline-flex items-center gap-3">
                    <IconComponent
                      className="w-6 h-6 text-[#d4af37]"
                    />
                    {item.href ? (
                      <a
                        className="text-lg leading-relaxed flex items-center justify-center font-sans font-semibold text-white hover:text-[#d4af37] text-center tracking-normal whitespace-nowrap transition-colors duration-300"
                        href={item.href}
                        rel="noopener noreferrer"
                        target="_blank"
                      >
                        {item.text}
                      </a>
                    ) : (
                      <div className="flex items-center justify-center font-sans font-semibold text-white text-lg text-center tracking-normal whitespace-nowrap">
                        {item.text}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
