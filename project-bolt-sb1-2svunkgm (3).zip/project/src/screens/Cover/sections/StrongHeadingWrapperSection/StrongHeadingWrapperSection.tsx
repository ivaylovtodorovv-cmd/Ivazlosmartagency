import React from "react";

export const StrongHeadingWrapperSection = (): JSX.Element => {
  return (
    <section className="flex items-center justify-center w-full px-[10.03px] py-[16.72px] gap-[4.18px]">
      <h2 className="flex items-center justify-center w-fit [font-family:'Unbounded',Helvetica] font-normal text-[26.8px] tracking-[0] leading-[29.4px] whitespace-nowrap">
        <span className="text-slate-400">WHAT WE CAN DO </span>
        <span className="text-[#0019ff]">FOR YOU?</span>
      </h2>
    </section>
  );
};
