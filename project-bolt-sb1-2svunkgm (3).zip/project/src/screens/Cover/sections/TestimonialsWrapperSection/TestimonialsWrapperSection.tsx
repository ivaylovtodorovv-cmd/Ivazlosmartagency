import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

const testimonials = [
  {
    quote:
      "Working with Conscellence was a game-changer for us. Their market analysis and insights helped us navigate challenging market conditions and seize new opportunities. Thanks to their expertise, we achieved record-breaking sales last quarter.",
    author: "MICHAEL THOMPSON, FOUNDER OF ECOGREEN SOLUTIONS",
    bgColor: "bg-[#0019ff]",
    quoteColor: "text-white",
    border: false,
  },
  {
    quote:
      "Conscellence transformed our business operations with their customized strategies. Their team identified key areas for improvement and provided actionable solutions that significantly boosted our efficiency and growth. We couldn't be happier with the results.",
    author: "EMMA RODRIGUEZ, CEO OF TRENDTECH INNOVATIONS",
    bgColor: "bg-transparent",
    quoteColor: "text-[#4a5bff]",
    border: true,
  },
  {
    quote:
      "The leadership training and team-building programs provided by Conscellence have been invaluable. Our team is now more cohesive and motivated, and our leaders are better equipped to drive the company forward. Cons truly understands our needs and delivers exceptional results.",
    author: "LISA NGUYEN, COO OF HEALTHYBITES INC.",
    bgColor: "bg-transparent",
    quoteColor: "text-[#4a5bff]",
    border: true,
  },
];

export const TestimonialsWrapperSection = (): JSX.Element => {
  return (
    <section className="relative w-full bg-slate-900 px-4 py-[83.61px] lg:pl-[133.78px] lg:pr-[10.03px]">
      <div className="flex flex-col items-start gap-[16.72px]">
        <h2 className="self-stretch text-center [font-family:'Unbounded',Helvetica] font-normal text-[26.8px] leading-[29.4px] tracking-[0] [-webkit-text-stroke:0.42px_#cbd5e1]">
          <span className="text-transparent">CLIENT </span>
          <span className="text-[#d9d9d9]">SUCCESS</span>
          <span className="text-transparent"> STORIES</span>
        </h2>

        <div className="flex items-start gap-[3.34px] w-full">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className={`flex-1 ${testimonial.bgColor} rounded-[16.72px] ${testimonial.border ? "border-[0.42px] border-white" : "border-0"}`}
            >
              <CardContent className="flex flex-col items-start gap-[10.03px] p-[16.72px]">
                <div className="flex flex-col items-start w-full">
                  <div className="[font-family:'Angry-Regular',Helvetica] font-normal text-[20.1px] leading-[28.1px] tracking-[0] whitespace-nowrap">
                    <span className={testimonial.quoteColor}>&quot;</span>
                  </div>
                  <p className="text-center [font-family:'Montserrat',Helvetica] font-medium text-white text-[6.7px] leading-[9.4px] tracking-[0]">
                    {testimonial.quote}
                  </p>
                </div>
                <p className="text-center [font-family:'Montserrat',Helvetica] font-bold text-slate-200 text-[5px] leading-[6.5px] tracking-[0.03px] w-full">
                  {testimonial.author}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <img
          className="flex-[0_0_auto]"
          alt="Navigation dots"
          src="/frame-1000005042.svg"
        />
      </div>

      <div className="absolute top-0 left-[calc(50%_-_301px)] w-[602px] h-[23px] bg-slate-50 rounded-[0px_0px_23.41px_23.41px]" />

      <div className="absolute bottom-px left-[calc(50%_-_301px)] w-[602px] h-[23px] bg-slate-500 rounded-[0px_0px_23.41px_23.41px] -rotate-180" />
    </section>
  );
};
