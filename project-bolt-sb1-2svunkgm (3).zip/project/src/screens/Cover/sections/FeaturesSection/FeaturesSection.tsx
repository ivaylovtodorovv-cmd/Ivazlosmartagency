import React, { useState } from "react";
import { Card, CardContent } from "../../../../components/ui/card";
import { Button } from "../../../../components/ui/button";
import { ArrowUpRightIcon } from "lucide-react";

const features = [
  {
    number: "01",
    title: "Нямате време за всичко?",
    description: `Управлението на клиенти, екип, маркетинг и административни задачи отнема целия ден.
Често сте **затрупани с рутинни задачи** и нямате време за стратегическо мислене.

**Как ви помагаме:**
- Автоматизираме повтарящи се дейности – имейли, запитвания, графици, оферти
- Въвеждаме AI асистенти, които подпомагат екипа в ежедневната работа
- Оптимизираме работния поток с no-code инструменти, така че да спестявате часове всяка седмица`,
  },
  {
    number: "02",
    title: "Маркетингът не носи реални резултати?",
    description: `Пускате реклами и публикувате в социалните мрежи, но **не виждате достатъчно нови клиенти**.
Бюджетът се харчи, без да е ясно какво наистина работи.

**Какво получавате:**
- Анализ на текущите ви кампании с помощта на AI
- Ясна маркетинг стратегия, базирана на данни, а не на предположения
- Оптимизация на рекламния бюджет и таргетирането, за да плащате по-малко за по-добри резултати`,
  },
  {
    number: "03",
    title: "Искате да използвате AI, но не знаете откъде да започнете?",
    description: `Чувате навсякъде за AI, но **инструментите и термините звучат твърде сложни**.
Не знаете кои решения са подходящи за вашия бизнес и как да ги внедрите ефективно.

**Какво правим за вас:**
- Оценяваме процесите във вашия бизнес и посочваме къде AI ще има най-голям ефект
- Предлагаме конкретни AI решения – чат асистенти, автоматизирани отчети, имейл системи и др.
- Обучаваме вас и екипа ви как да използвате тези инструменти уверено в ежедневната работа`,
  },
];

const renderFormattedText = (text: string) => {
  const lines = text.split('\n');
  return lines.map((line, index) => {
    const isBold = line.includes('**');
    const isBullet = line.trim().startsWith('-');

    if (isBold) {
      const parts = line.split('**');
      return (
        <p key={index} className="mb-3 text-base md:text-lg leading-[1.5] text-white">
          {parts.map((part, i) => (
            i % 2 === 1 ? <strong key={i} className="font-bold text-white">{part}</strong> : part
          ))}
        </p>
      );
    }

    if (isBullet) {
      return (
        <li key={index} className="ml-6 mb-3 text-base md:text-lg leading-[1.5] list-disc text-white">
          {line.substring(1).trim()}
        </li>
      );
    }

    if (line.trim() === '') {
      return <div key={index} className="h-2" />;
    }

    return (
      <p key={index} className="mb-3 text-base md:text-lg leading-[1.5] text-white">
        {line}
      </p>
    );
  });
};

export const FeaturesSection = (): JSX.Element => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const handleCtaClick = () => {
    const button = document.querySelector('button') as HTMLButtonElement;
    const buttons = document.querySelectorAll('button');
    for (const btn of buttons) {
      if (btn.innerText.includes('ЗАПОЧНЕТЕ СЕГА') || btn.innerText.includes('ИЗИСКАЙ КОНСУЛТАЦИЯ')) {
        btn.click();
        break;
      }
    }
  };

  return (
    <section className="py-24 md:py-40 w-full overflow-x-hidden bg-[#1a3a52]">
      <div className="container mx-auto max-w-7xl px-6 md:px-16">
        <div className="flex flex-col items-center gap-10 md:gap-12">
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-[#d4af37] text-center mb-8 md:mb-16">
            Сблъсквате ли се с тези предизвикателства?
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 w-full">
            {features.map((feature, index) => (
              <Card
                key={index}
                onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
                className="bg-[#1a3a52]/60 border-2 border-[#d4af37]/30 rounded-3xl p-10 hover:border-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/30 transition-all duration-500 hover:-translate-y-2 h-full flex flex-col backdrop-blur-sm cursor-pointer"
              >
                <CardContent className="flex flex-col items-start gap-4 p-0 flex-1">
                  <div className="text-[#d4af37] font-bold text-2xl mb-4">
                    {feature.number}
                  </div>

                  <h3 className={`text-xl md:text-3xl font-serif font-bold text-[#1a3a52] bg-gradient-to-r from-[#d4af37] to-[#f0d77c] px-4 md:px-6 py-2 md:py-3 rounded-2xl mb-4 inline-block transition-all duration-300 ${
                    expandedIndex === index
                      ? 'shadow-2xl shadow-[#d4af37]/60'
                      : 'shadow-xl hover:shadow-[#d4af37]/60'
                  }`}>
                    {feature.title}
                  </h3>

                  {expandedIndex === index && (
                    <div
                      className="w-full font-sans mt-2 p-5 rounded-xl bg-black/40 animate-in slide-in-from-top-2 fade-in duration-300"
                    >
                      {renderFormattedText(feature.description)}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="w-full max-w-4xl mt-16 bg-[#1a3a52]/40 backdrop-blur-sm border-2 border-[#d4af37]/30 rounded-3xl p-10 md:p-12 text-center hover:border-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/30 transition-all duration-500">
            <p className="text-white/90 text-xl md:text-2xl font-sans leading-relaxed mb-8">
              Разпознавате ли бизнеса си в някое от тези предизвикателства?<br />
              Нека обсъдим как AI може да работи за вас, а не срещу вас.
            </p>
            <Button
              onClick={handleCtaClick}
              className="w-full md:w-auto h-auto items-center gap-4 px-14 py-7 bg-gradient-to-r from-[#d4af37] to-[#f0d77c] rounded-[30px] hover:from-[#f0d77c] hover:to-[#d4af37] font-sans font-bold text-[#1a3a52] text-xl tracking-wide shadow-2xl hover:shadow-[#d4af37]/60 transition-all duration-300 hover:scale-105 transform"
            >
              Запази безплатна консултация
              <ArrowUpRightIcon className="w-6 h-6 text-[#1a3a52]" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
