import { ArrowRightIcon } from "lucide-react";
import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const AboutUsWrapperSection = (): JSX.Element => {
  return (
    <Card className="w-full bg-slate-50 rounded-[23.41px] border-0 shadow-none">
      <CardContent className="flex items-start justify-between gap-[33.44px] p-[50.17px] relative">
        <div className="flex flex-col items-start gap-0">
          <div className="flex items-center gap-[85.28px]">
            <h2 className="[font-family:'Unbounded',Helvetica] font-normal text-slate-900 text-[26.8px] tracking-[0] leading-[29.4px] whitespace-nowrap">
              OUR
            </h2>
            <ArrowRightIcon className="w-[33.44px] h-[33.44px] text-slate-900" />
          </div>
          <h2 className="[font-family:'Unbounded',Helvetica] font-normal text-slate-900 text-[26.8px] tracking-[0] leading-[29.4px] whitespace-nowrap">
            APPROACH
          </h2>
        </div>

        <div className="relative flex-1 flex items-center justify-center">
          <img
            className="w-[259px] h-[229px] object-cover"
            alt="Element removebg"
            src="/3-removebg-1.png"
          />
        </div>

        <div className="flex items-end flex-1 pt-[79.43px] pl-[21.74px]">
          <p className="[font-family:'Montserrat',Helvetica] font-normal text-[8.4px] tracking-[0] leading-[8.4px]">
            <span className="font-medium text-slate-500 leading-[12.5px]">
              Discover our unique consulting methodology that combines in-depth
              industry knowledge, innovative thinking, and a client-centric
              approach.{" "}
            </span>
            <span className="font-medium text-slate-900 leading-[12.5px]">
              We partner with you every step of the way to ensure your business
              reaches its full potential.
            </span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
