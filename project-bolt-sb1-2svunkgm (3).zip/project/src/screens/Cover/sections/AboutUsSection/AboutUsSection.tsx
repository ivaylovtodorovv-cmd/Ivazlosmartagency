import { ArrowRight as ArrowRightIcon } from "lucide-react";
import React, { useState } from "react";
import { Button } from "../../../../components/ui/button";

const renderFormattedText = (text: string) => {
  const lines = text.split('\n');
  return lines.map((line, index) => {
    const isExample = line.trim().startsWith('>');
    const isBold = line.includes('**');

    if (isExample) {
      const cleanLine = line.replace(/^>\s*/, '');
      const parts = cleanLine.split('*');
      return (
        <p key={index} className="text-[#d4af37]/90 text-sm md:text-base leading-[1.5] mb-2 italic pl-4 border-l-2 border-[#d4af37]/50">
          {parts.map((part, i) => (
            i % 2 === 1 ? <strong key={i} className="font-bold">{part}</strong> : part
          ))}
        </p>
      );
    }

    if (isBold) {
      const parts = line.split('**');
      return (
        <p key={index} className="text-white text-base md:text-lg leading-[1.5] mb-3">
          {parts.map((part, i) => (
            i % 2 === 1 ? <strong key={i} className="font-bold text-white">{part}</strong> : part
          ))}
        </p>
      );
    }

    if (line.trim() === '') {
      return <div key={index} className="h-2" />;
    }

    return (
      <p key={index} className="text-white text-base md:text-lg leading-[1.5] mb-3">
        {line}
      </p>
    );
  });
};

const stepsData = [
  {
    number: "01",
    title: "Анализ и цели",
    content: `Започваме с **одит на текущите процеси** във вашия бизнес – как се обработват поръчки, как се комуникира с клиенти, как се съхраняват данни и кои задачи отнемат най-много време.
След това **идентифицираме възможностите за оптимизация** чрез изкуствен интелект, автоматизация или дигитализация.
Заедно определяме **конкретни цели и измерими резултати**, така че да знаете точно какво ще получите.
> *Резултат:* **Ясен план** къде и как AI може да ви донесе реална стойност още в първите месеци.`
  },
  {
    number: "02",
    title: "AI стратегия",
    content: `На базата на анализа разработваме **персонализирана AI стратегия**, съобразена с вашия бизнес модел, бюджет и капацитет на екипа.
В нея описваме конкретните решения – от **интелигентни асистенти и автоматизирани системи** до инструменти за маркетинг и управление.
> *Резултат:* **Стратегическа пътна карта** за внедряване на подходящи AI решения с ясен график и очакван ефект.`
  },
  {
    number: "03",
    title: "Интеграция",
    content: `След като стратегията е готова, започваме внедряването.
Изграждаме и свързваме необходимите инструменти – **AI системи, no-code приложения и автоматизации**, така че да работят заедно с вече съществуващите процеси.
Работим така, че **да не спираме бизнеса ви нито за ден** – всичко се внедрява плавно и без излишна сложност.
> *Резултат:* **Интегрирани решения**, които автоматично работят във фона и ви пестят време ежедневно.`
  },
  {
    number: "04",
    title: "Обучение и поддръжка",
    content: `След внедряването осигуряваме **обучение на вашия екип**, така че всеки да може уверено да използва новите инструменти.
Предоставяме и **постоянна поддръжка и оптимизация** – защото технологиите се развиват, а ние се грижим да извличате максимума от тях.
> *Резултат:* **Уверен екип**, който използва AI ефективно, с нашата подкрепа, когато имате нужда.`
  }
];

export const AboutUsSection = (): JSX.Element => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const handleCtaClick = () => {
    const buttons = document.querySelectorAll('button');
    for (const btn of buttons) {
      if (btn.innerText.includes('ЗАПОЧНЕТЕ СЕГА') || btn.innerText.includes('ИЗИСКАЙ КОНСУЛТАЦИЯ')) {
        btn.click();
        break;
      }
    }
  };

  return (
    <section id="za-nas" className="py-24 md:py-40 bg-[#1a3a52] w-full overflow-x-hidden relative">
      <div className="container mx-auto max-w-7xl px-6 md:px-16 relative z-10">
        <div className="flex flex-col items-center gap-12 w-full">
          <div className="text-center mb-4 md:mb-8">
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-[#d4af37] mb-4">
              Как работим с вас?
            </h2>
            <p className="text-lg md:text-xl text-white font-semibold font-sans leading-relaxed max-w-4xl mx-auto">
              Превръщаме технологиите в реални резултати – стъпка по стъпка.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 w-full">
            {stepsData.map((step, index) => (
              <div
                key={index}
                onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
                className="bg-[#1a3a52]/60 backdrop-blur-sm rounded-2xl p-6 md:p-10 border-2 border-[#d4af37]/30 hover:border-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/30 transition-all duration-500 cursor-pointer"
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-[#d4af37] font-bold text-4xl">{step.number}</div>
                  <h3 className="font-serif font-bold text-white text-xl md:text-3xl">{step.title}</h3>
                </div>
                {expandedIndex === index && (
                  <div className="font-sans mt-4 animate-in slide-in-from-top-2 fade-in duration-300">
                    {renderFormattedText(step.content)}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="w-full max-w-4xl mt-16 bg-[#1a3a52]/40 backdrop-blur-sm border-2 border-[#d4af37]/30 rounded-3xl p-10 md:p-12 text-center hover:border-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/30 transition-all duration-500">
            <p className="text-white text-2xl md:text-3xl font-serif font-bold leading-relaxed mb-4">
              Готови ли сте да направим първата стъпка?
            </p>
            <p className="text-white/80 text-lg md:text-xl italic font-sans leading-relaxed mb-8">
              Нека открием заедно как AI може да развие вашия бизнес.
            </p>
            <Button
              onClick={handleCtaClick}
              className="w-full md:w-auto h-auto items-center gap-4 px-14 py-7 bg-gradient-to-r from-[#d4af37] to-[#f0d77c] rounded-[30px] hover:from-[#f0d77c] hover:to-[#d4af37] font-sans font-bold text-[#1a3a52] text-xl tracking-wide shadow-2xl hover:shadow-[#d4af37]/60 transition-all duration-300 hover:scale-105 transform"
            >
              Запази безплатна консултация
              <ArrowRightIcon className="w-6 h-6 text-[#1a3a52]" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
