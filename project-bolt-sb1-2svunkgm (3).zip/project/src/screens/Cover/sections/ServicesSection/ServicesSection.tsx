import { ArrowRight as ArrowRightIcon, ArrowUpRight as ArrowUpRightIcon } from "lucide-react";
import React, { useState } from "react";
import { Button } from "../../../../components/ui/button";

const servicesData = [
  {
    title: "AI внедряване и стратегически консултации",
    shortIntro: "Изкуственият интелект не е само за големите корпорации. Ние ви показваме **как да го използвате във вашия реален бизнес** – с реална възвръщаемост, не просто модерна дума.",
    fullText: `След задълбочена консултация подбираме конкретни AI решения, които **пестят време, пари и човешки ресурс**.
> *Пример:* Автоматично генериране на оферти или анализ на клиентски запитвания без човешка намеса.`,
  },
  {
    title: "Обучение и подкрепа на екипа",
    shortIntro: "Въвеждаме технологиите плавно и разбираемо – **без сложен жаргон и излишна теория**.",
    fullText: `Обучаваме екипа ви да използва AI инструменти **ефективно**, така че подобрението да остане трайно.
Провеждаме индивидуални и групови обучения според нуждите на вашия бизнес.
> *Пример:* Обучение как да използвате ChatGPT, Canva, Notion AI и други инструменти за ежедневни задачи.`,
  },
  {
    title: "Интелигентни асистенти и AI агенти",
    shortIntro: "Представете си дигитален служител, който **отговаря на запитвания, пише имейли и обработва данни вместо вас**.",
    fullText: `AI асистентите и агентите могат да поемат част от клиентската комуникация, техническата поддръжка или дори вътрешната организация на екипа.
> *Пример:* AI асистент, който приема заявки от клиенти на сайта и ги въвежда директно в системата ви.`,
  },
  {
    title: "Автоматизация на ключови процеси",
    shortIntro: "Освободете екипа си от повтарящите се задачи.",
    fullText: `Свързваме инструментите, които вече използвате (имейли, CRM, Google Sheets, социални мрежи), така че **всичко да работи автоматично и синхронизирано**.
> *Пример:* Нов клиент попълва форма → системата автоматично създава запис в CRM → изпраща потвърждение по имейл → добавя задачата към екипа.`,
  },
  {
    title: "No-code / Low-code интеграции",
    shortIntro: "Създаваме **персонализирани приложения без писане на код** – бързо, достъпно и напълно адаптирано към нуждите ви.",
    fullText: `От онлайн магазини и уебсайтове до вътрешни системи за склад, фактуриране или управление на клиенти – всичко може да се изгради **за дни, не месеци**.
> *Пример:* Мини система за издаване на фактури и следене на наличности, създадена без програмиране, специално за вашия бизнес.`,
  },
];

const renderFormattedText = (text: string) => {
  const lines = text.split('\n');
  return lines.map((line, index) => {
    const isExample = line.trim().startsWith('>');
    const isBold = line.includes('**');

    if (isExample) {
      const cleanLine = line.replace(/^>\s*/, '');
      const parts = cleanLine.split('*');
      return (
        <p key={index} className="text-white/80 text-sm md:text-base leading-[1.5] mb-2 italic pl-4 border-l-2 border-[#d4af37]/50">
          {parts.map((part, i) => (
            i % 2 === 1 ? <em key={i}>{part}</em> : part
          ))}
        </p>
      );
    }

    if (isBold) {
      const parts = line.split('**');
      return (
        <p key={index} className="text-white text-base md:text-lg leading-[1.5] mb-3">
          {parts.map((part, i) => (
            i % 2 === 1 ? <strong key={i} className="font-bold text-white">{part}</strong> : part
          ))}
        </p>
      );
    }

    if (line.trim() === '') {
      return <div key={index} className="h-2" />;
    }

    return (
      <p key={index} className="text-white text-base md:text-lg leading-[1.5] mb-3">
        {line}
      </p>
    );
  });
};

export const ServicesSection = (): JSX.Element => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  return (
    <section className="relative py-24 md:py-40 w-full overflow-x-hidden bg-[#1a3a52]">
      <div className="container mx-auto max-w-7xl px-6 md:px-16 relative z-10">
        <div className="flex flex-col items-center w-full gap-8 md:gap-12">
          <div className="text-center mb-4 md:mb-8">
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-[#d4af37] mb-4">
              Нашите умни решения за растеж на вашия бизнес
            </h2>
            <p className="text-lg md:text-xl font-sans font-semibold leading-relaxed max-w-4xl mx-auto text-white">
              Комбинираме изкуствен интелект, автоматизация и дигитални решения, за да изградим устойчива стратегия за успех.
            </p>
          </div>

          <div className="flex flex-col items-start w-full gap-8 md:gap-12">
          {servicesData.map((service, index) => (
            <div
              key={index}
              onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
              className="flex flex-col items-start gap-6 p-6 md:p-10 w-full bg-[#1a3a52]/60 backdrop-blur-sm rounded-[30px] border-2 border-[#d4af37]/30 shadow-xl hover:border-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/30 hover:-translate-y-2 transition-all duration-500 ease-in-out opacity-0 animate-fade-in cursor-pointer"
            >
              <div className="flex items-start gap-6 w-full">
                <div className="flex-1">
                  <h3 className="inline-block text-xl md:text-3xl font-serif font-bold text-[#1a3a52] bg-gradient-to-r from-[#d4af37] to-[#f0d77c] px-4 md:px-6 py-2 md:py-3 rounded-2xl shadow-xl hover:shadow-[#d4af37]/60 transition-all duration-300 mb-4">
                    {service.title}
                  </h3>

                  <div className="mt-4">
                    {renderFormattedText(service.shortIntro)}
                  </div>
                </div>
              </div>

              {expandedIndex === index && (
                <div className="w-full mt-2 p-5 rounded-xl bg-black/40 animate-in slide-in-from-top-2 fade-in duration-300">
                  {renderFormattedText(service.fullText)}
                </div>
              )}
            </div>
          ))}

          <div className="relative flex flex-col md:flex-row items-center gap-6 md:gap-12 p-10 md:p-12 w-full bg-[#1a3a52]/40 backdrop-blur-sm rounded-[30px] border-2 border-[#d4af37]/30 shadow-2xl hover:border-[#d4af37] hover:shadow-2xl hover:shadow-[#d4af37]/30 hover:-translate-y-2 transition-all duration-500 ease-in-out overflow-hidden">
            <div className="relative flex items-center justify-center flex-1 font-serif font-bold text-white text-3xl md:text-4xl tracking-tight leading-tight text-center md:text-left">
              Безплатна консултация
            </div>

            <div className="relative flex flex-col sm:flex-row items-center gap-6 flex-1">
              <Button
                variant="outline"
                className="w-full sm:w-auto h-auto gap-3 px-10 py-5 rounded-[30px] border-2 border-transparent bg-gradient-to-r from-[#d4af37] to-[#f0d77c] text-[#1a3a52] hover:from-[#f0d77c] hover:to-[#d4af37] font-sans font-bold text-base tracking-wide transition-all duration-500 shadow-xl hover:shadow-2xl hover:shadow-[#d4af37]/60 hover:scale-105"
              >
                ЗАПИШЕТЕ РАЗГОВОР
                <ArrowUpRightIcon className="w-5 h-5" />
              </Button>

            </div>
          </div>
          </div>
        </div>
      </div>
    </section>
  );
};
