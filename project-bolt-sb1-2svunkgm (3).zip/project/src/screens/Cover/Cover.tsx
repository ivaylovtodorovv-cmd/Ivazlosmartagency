import React from "react";
import { Badge } from "../../components/ui/badge";
import { AboutUsSection } from "./sections/AboutUsSection";
import { AboutUsWrapperSection } from "./sections/AboutUsWrapperSection";
import { ContactUsSection } from "./sections/ContactUsSection";
import { ContactUsWrapperSection } from "./sections/ContactUsWrapperSection";
import { FeaturesSection } from "./sections/FeaturesSection";
import { FeaturesWrapperSection } from "./sections/FeaturesWrapperSection";
import { FooterSection } from "./sections/FooterSection";
import { FooterWrapperSection } from "./sections/FooterWrapperSection";
import { FrameSection } from "./sections/FrameSection";
import { HeroSection } from "./sections/HeroSection";
import { HeroWrapperSection } from "./sections/HeroWrapperSection";
import { MainHeadlineSection } from "./sections/MainHeadlineSection";
import { ServicesSection } from "./sections/ServicesSection";
import { StrongHeadingSection } from "./sections/StrongHeadingSection";
import { StrongHeadingWrapperSection } from "./sections/StrongHeadingWrapperSection";
import { TestimonialsSection } from "./sections/TestimonialsSection";
import { TestimonialsWrapperSection } from "./sections/TestimonialsWrapperSection";
import { ContactFormModal } from "../../components/ContactFormModal";
import { useContactModal } from "../../hooks/useContactModal";

export const Cover = (): JSX.Element => {
  const { isOpen, source, closeModal } = useContactModal();
  return (
    <main className="w-full min-h-screen relative scroll-smooth">
      <HeroSection />

      <section className="relative">
        <div className="relative z-10">
          <FeaturesSection />
        </div>
      </section>

      <section id="uslugi" className="relative">
        <div className="relative z-10">
          <ServicesSection />
        </div>
      </section>

      <section id="za-nas" className="relative">
        <div className="relative z-10">
          <AboutUsSection />
        </div>
      </section>

      <section id="misia" className="relative">
        <div className="relative z-10">
          <TestimonialsSection />
        </div>
      </section>

      <section id="kontakti" className="relative">
        <div className="relative z-10">
          <ContactUsSection />
        </div>
      </section>

      <section className="relative">
        <div className="relative z-10">
          <FooterSection />
        </div>
      </section>

      <ContactFormModal isOpen={isOpen} onClose={closeModal} source={source} />
    </main>
  );
};
