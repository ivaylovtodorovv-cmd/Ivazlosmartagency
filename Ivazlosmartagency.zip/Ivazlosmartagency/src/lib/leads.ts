// [leads-wireup] Lead submission logic for CTA buttons

interface ToastOptions {
  type: 'success' | 'error';
  message: string;
  duration?: number;
}

let toastTimeout: NodeJS.Timeout | null = null;

export const showToast = (options: ToastOptions) => {
  const { type, message, duration = 3000 } = options;

  const existingToast = document.getElementById('leads-toast');
  if (existingToast) {
    existingToast.remove();
  }

  if (toastTimeout) {
    clearTimeout(toastTimeout);
  }

  const toast = document.createElement('div');
  toast.id = 'leads-toast';
  toast.className = `fixed bottom-6 right-6 px-6 py-4 rounded-xl shadow-lg text-white font-semibold z-50 animate-fade-in transition-all duration-300 ${
    type === 'success'
      ? 'bg-green-600'
      : 'bg-red-600'
  }`;
  toast.textContent = message;
  toast.style.maxWidth = '400px';
  toast.style.wordWrap = 'break-word';

  document.body.appendChild(toast);

  toastTimeout = setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, duration);
};

export const validateEmail = (email: string): boolean => {
  const emailRegex = /.+@.+\..+/;
  return emailRegex.test(email.trim());
};

export const submitLead = async (
  email: string,
  source: 'hero' | 'services-cta' | 'footer'
): Promise<boolean> => {
  if (!validateEmail(email)) {
    showToast({
      type: 'error',
      message: 'Моля, въведете валидна поща.',
    });
    return false;
  }

  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn('[leads] Supabase config missing');
      return false;
    }

    const response = await fetch(`${supabaseUrl}/rest/v1/leads`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: supabaseAnonKey,
        Authorization: `Bearer ${supabaseAnonKey}`,
      },
      body: JSON.stringify({
        email: email.trim(),
        source,
        page_url: window.location.href,
        user_agent: navigator.userAgent,
        ip_address: null,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to submit lead');
    }

    await fetch(`${supabaseUrl}/functions/v1/send-lead-email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${supabaseAnonKey}`,
      },
      body: JSON.stringify({
        email: email.trim(),
        source,
        pageUrl: window.location.href,
        userAgent: navigator.userAgent,
      }),
    }).catch((err) => {
      console.warn('[leads] Email notification failed (non-blocking):', err);
    });

    showToast({
      type: 'success',
      message: 'Заявката е изпратена. Ще се свържем скоро.',
    });

    return true;
  } catch (error) {
    console.error('[leads] Submission error:', error);
    showToast({
      type: 'error',
      message: 'Неуспешно изпращане. Опитайте отново.',
    });
    return false;
  }
};

export const createDebouncedSubmit = (
  submitFn: () => Promise<void>,
  delay = 300
) => {
  let timeout: NodeJS.Timeout | null = null;
  let isSubmitting = false;

  return async () => {
    if (isSubmitting) return;

    if (timeout) {
      clearTimeout(timeout);
    }

    isSubmitting = true;
    timeout = setTimeout(async () => {
      try {
        await submitFn();
      } finally {
        isSubmitting = false;
      }
    }, delay);
  };
};

export const smoothScrollTo = (element: Element) => {
  element.scrollIntoView({ behavior: 'smooth', block: 'start' });
};
