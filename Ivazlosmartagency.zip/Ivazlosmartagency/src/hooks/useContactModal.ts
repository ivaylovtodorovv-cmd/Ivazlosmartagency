import { useState, useEffect } from 'react';

export const useContactModal = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [source, setSource] = useState<'hero' | 'footer'>('hero');

  useEffect(() => {
    const findButtonByText = (text: string): HTMLElement | null => {
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        if (btn.innerText.trim() === text) {
          return btn;
        }
      }
      return null;
    };

    const heroButton = findButtonByText('ЗАПОЧНЕТЕ СЕГА');
    if (heroButton) {
      const handleHeroClick = (e: Event) => {
        e.preventDefault();
        setSource('hero');
        setIsOpen(true);
      };
      heroButton.addEventListener('click', handleHeroClick);
    }

    const footerButton = findButtonByText('ИЗИСКАЙ КОНСУЛТАЦИЯ');
    if (footerButton) {
      const handleFooterClick = (e: Event) => {
        e.preventDefault();
        setSource('footer');
        setIsOpen(true);
      };
      footerButton.addEventListener('click', handleFooterClick);
    }

    const serviceButton = findButtonByText('ЗАПИШЕТЕ РАЗГОВОР');
    if (serviceButton) {
      const handleServiceClick = (e: Event) => {
        e.preventDefault();
        setSource('hero');
        setIsOpen(true);
      };
      serviceButton.addEventListener('click', handleServiceClick);
    }

    return () => {};
  }, []);

  const closeModal = () => {
    setIsOpen(false);
  };

  return { isOpen, source, closeModal };
};
