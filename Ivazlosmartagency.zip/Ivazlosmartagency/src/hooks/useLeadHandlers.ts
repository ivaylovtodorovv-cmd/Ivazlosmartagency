import { useEffect } from 'react';
import { submitLead, createDebouncedSubmit, smoothScrollTo } from '../lib/leads';

export const useLeadHandlers = () => {
  useEffect(() => {
    const findEmailInput = (button: HTMLElement): HTMLInputElement | null => {
      let current = button.parentElement;
      while (current) {
        const emailInput = current.querySelector('input[type="email"]') as HTMLInputElement;
        if (emailInput) {
          return emailInput;
        }
        current = current.parentElement;
      }
      return null;
    };

    const findButtonByText = (text: string): HTMLElement | null => {
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        if (btn.innerText.trim() === text) {
          return btn;
        }
      }
      return null;
    };

    const heroButton = findButtonByText('ЗАПОЧНЕТЕ СЕГА');
    if (heroButton) {
      const debouncedHeroSubmit = createDebouncedSubmit(async () => {
        const emailInput = findEmailInput(heroButton);
        if (emailInput) {
          const originalText = heroButton.innerText;
          heroButton.setAttribute('disabled', 'true');
          heroButton.innerText = 'Изпращане...';

          const success = await submitLead(emailInput.value, 'hero');

          if (success) {
            emailInput.value = '';
          }

          heroButton.removeAttribute('disabled');
          heroButton.innerText = originalText;
        }
      }, 300);

      heroButton.addEventListener('click', debouncedHeroSubmit);
    } else {
      console.warn('[leads] Hero button not found');
    }

    const servicesButton = findButtonByText('ЗАПИШЕТЕ РАЗГОВОР');
    if (servicesButton) {
      const handleServicesClick = () => {
        const footerInput = document.querySelector(
          '#kontakti input[type="email"]'
        ) as HTMLInputElement;

        if (footerInput) {
          smoothScrollTo(footerInput);
          setTimeout(() => {
            footerInput.focus();
          }, 800);
        } else {
          console.warn('[leads] Footer input not found');
        }
      };

      servicesButton.addEventListener('click', handleServicesClick);
    } else {
      console.warn('[leads] Services button not found');
    }

    const footerButton = findButtonByText('ИЗПРАТИ');
    if (footerButton) {
      const debouncedFooterSubmit = createDebouncedSubmit(async () => {
        const emailInput = findEmailInput(footerButton);
        if (emailInput) {
          const originalText = footerButton.innerText;
          footerButton.setAttribute('disabled', 'true');
          footerButton.innerText = 'Изпращане...';

          const success = await submitLead(emailInput.value, 'footer');

          if (success) {
            emailInput.value = '';
          }

          footerButton.removeAttribute('disabled');
          footerButton.innerText = originalText;
        }
      }, 300);

      footerButton.addEventListener('click', debouncedFooterSubmit);
    } else {
      console.warn('[leads] Footer button not found');
    }

    return () => {};
  }, []);
};
