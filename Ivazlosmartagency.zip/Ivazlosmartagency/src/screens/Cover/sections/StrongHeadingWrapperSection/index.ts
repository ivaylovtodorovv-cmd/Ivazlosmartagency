export { StrongHeadingWrapperSection } from "./StrongHeadingWrapperSection";
