import React from "react";

export const StrongHeadingSection = (): JSX.Element => {
  return (
    <div className="flex items-center justify-center h-auto font-serif font-bold text-7xl md:text-8xl tracking-tight leading-none py-16">
      <div className="flex flex-col items-center">
        <div className="[-webkit-text-stroke:2px_#d97706] text-transparent leading-tight">
          CONSULTING
        </div>
        <div className="text-amber-500 leading-none font-light italic">website</div>
        <div className="[-webkit-text-stroke:2px_#d97706] text-transparent leading-tight">
          template
        </div>
      </div>
    </div>
  );
};
