import React from "react";

export const FooterWrapperSection = (): JSX.Element => {
  return (
    <footer className="px-[33.44px] py-[10.03px] flex items-center justify-center w-full bg-slate-900">
      <div className="[font-family:'Montserrat',Helvetica] font-medium text-white text-[10px] tracking-[0] leading-[14px] whitespace-nowrap text-center">
        All rights reserved © 2024 Ivaylo's Smart Agency
      </div>
    </footer>
  );
};
