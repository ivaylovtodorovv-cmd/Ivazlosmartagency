import { ArrowUpRight as ArrowUpRightIcon, Mail as MailIcon, Menu as MenuIcon, Bone as XIcon } from "lucide-react";
import React, { useState, useEffect } from "react";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";

const navigationItems = [
  { label: "УСЛУГИ", href: "#uslugi" },
  { label: "ЗА НАС", href: "#za-nas" },
  { label: "МИСИЯ", href: "#misia" },
  { label: "КОНТАКТИ", href: "#kontakti" },
];

export const HeroSection = (): JSX.Element => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["uslugi", "za-nas", "misia", "kontakti"];
      const scrollPosition = window.scrollY + 200;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(`#${section}`);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    element?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <section className="flex flex-col items-start relative w-full overflow-hidden bg-[#1a3a52]">
      <header className="px-8 md:px-16 py-5 flex items-center justify-between relative w-full sticky top-0 backdrop-blur-md bg-[#1a3a52]/95 z-50 border-b border-[#d4af37]/30 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="font-serif font-bold text-[#d4af37] text-xl tracking-tight">
            Ivaylo's Smart Agency
          </div>
        </div>

        <nav className="hidden md:inline-flex items-center">
          {navigationItems.map((item, index) => (
            <Button
              key={index}
              variant="ghost"
              className={`h-auto gap-2 px-6 py-3 rounded-xl font-sans font-medium text-white text-base hover:bg-[#d4af37]/10 hover:text-[#d4af37] transition-all duration-300 ${
                activeSection === item.href ? 'bg-[#d4af37]/10 text-[#d4af37] font-semibold' : ''
              }`}
              onClick={() => handleNavClick(item.href)}
            >
              {item.label}
            </Button>
          ))}
        </nav>

        <div className="hidden md:block">
          <a href="tel:+359892337322">
            <Button
              variant="outline"
              className="h-auto gap-2 px-6 py-3 rounded-full border-2 border-[#d4af37] bg-transparent font-sans font-semibold text-[#d4af37] text-base hover:bg-[#d4af37] hover:text-[#1a3a52] transition-all duration-300 shadow-lg hover:shadow-[#d4af37]/50 hover:scale-105"
            >
              0892 337 322
            </Button>
          </a>
        </div>

        <Button
          variant="ghost"
          className="md:hidden p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <XIcon className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
        </Button>
      </header>

      {mobileMenuOpen && (
        <div className="md:hidden w-full bg-[#1a3a52]/95 backdrop-blur-md border-b border-[#d4af37]/30">
          <nav className="flex flex-col p-4">
            {navigationItems.map((item, index) => (
              <Button
                key={index}
                variant="ghost"
                className={`w-full justify-start h-12 text-left font-sans font-medium text-white text-base hover:bg-[#d4af37]/10 hover:text-[#d4af37] transition-all duration-300 ${
                  activeSection === item.href ? 'bg-[#d4af37]/10 text-[#d4af37] font-semibold' : ''
                }`}
                onClick={() => handleNavClick(item.href)}
              >
                {item.label}
              </Button>
            ))}
            <a href="tel:+359892337322" className="w-full">
              <Button
                variant="outline"
                className="w-full mt-4 h-12 rounded-full border-2 border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a3a52] transition-all duration-300 hover:scale-105"
              >
                0892 337 322
              </Button>
            </a>
          </nav>
        </div>
      )}

      <div className="flex items-center justify-center relative w-full min-h-[700px] md:min-h-[800px] z-10 px-6 md:px-16 py-32 md:py-40">
        <div className="flex flex-col items-center gap-8 md:gap-12 max-w-5xl w-full relative z-10">
          <div className="flex flex-col items-center gap-6 w-full text-center">
            <h1 className="w-full font-serif font-bold text-4xl md:text-7xl tracking-tight leading-tight text-white drop-shadow-2xl">
              <span className="inline text-[#d4af37]">
                Отключете потенциала{" "}
              </span>
              <span className="inline text-white">
                на вашия бизнес с AI
              </span>
            </h1>

            <p className="w-full font-sans font-semibold text-white text-lg md:text-2xl tracking-normal leading-relaxed max-w-3xl">
              Достъпни и ефективни AI решения за малкия и среден бизнес. Автоматизирайте задачи, анализирайте данни и постигнете повече с по-малко ресурси.
            </p>
          </div>

          <div className="flex items-center justify-center w-full mt-6">
            <Button className="h-auto items-center gap-4 px-10 md:px-14 py-6 md:py-7 bg-gradient-to-r from-[#d4af37] to-[#f0d77c] rounded-[30px] hover:from-[#f0d77c] hover:to-[#d4af37] font-sans font-bold text-[#1a3a52] text-lg md:text-xl tracking-wide shadow-2xl hover:shadow-[#d4af37]/60 transition-all duration-300 hover:scale-105 transform">
              ЗАПОЧНЕТЕ СЕГА
              <div className="gap-2 p-2.5 rounded-lg inline-flex flex-col items-center justify-center bg-[#1a3a52]/20 backdrop-blur-sm">
                <ArrowUpRightIcon className="w-5 h-5 md:w-6 md:h-6 text-[#1a3a52]" />
              </div>
            </Button>
          </div>
        </div>
      </div>

    </section>
  );
};
