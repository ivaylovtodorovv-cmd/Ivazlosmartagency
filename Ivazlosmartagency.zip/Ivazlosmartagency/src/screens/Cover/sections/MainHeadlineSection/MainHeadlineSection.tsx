import React from "react";

export const MainHeadlineSection = (): JSX.Element => {
  return (
    <section className="flex items-center justify-center w-full px-4 py-7">
      <h1 className="[font-family:'Unbounded',Helvetica] font-normal text-[42.3px] tracking-[0] leading-[46.5px] whitespace-nowrap text-center">
        <span className="text-slate-400">WHAT WE CAN DO </span>
        <span className="text-[#0019ff]">FOR YOU?</span>
      </h1>
    </section>
  );
};
