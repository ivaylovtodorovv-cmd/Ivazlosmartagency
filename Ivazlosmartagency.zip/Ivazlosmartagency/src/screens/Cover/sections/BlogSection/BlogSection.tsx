import React from "react";
import { BookOpen } from "lucide-react";

export const BlogSection = (): JSX.Element => {
  return (
    <section className="py-32 md:py-40 w-full overflow-x-hidden relative bg-[#1a3a52] bg-[url('/Untitled%20design.png')] bg-repeat">
      <div className="container mx-auto max-w-7xl px-6 md:px-16 relative z-10">
        <div className="flex flex-col items-center gap-12 bg-[#1a3a52]/40 backdrop-blur-sm p-12 md:p-16 rounded-3xl shadow-2xl border-2 border-[#d4af37]/30 hover:border-[#d4af37] hover:shadow-[#d4af37]/30 transition-all duration-500 hover:-translate-y-2">
          <div className="flex items-center gap-4">
            <BookOpen className="w-12 h-12 text-[#d4af37]" />
            <h2 className="font-serif font-bold text-white text-5xl md:text-6xl tracking-tight leading-tight">
              Блог и полезни ресурси
            </h2>
          </div>

          <p className="font-sans text-white/90 text-xl md:text-2xl tracking-normal leading-relaxed text-center max-w-4xl">
            В нашия блог ще откриете практически съвети, ръководства и новини за това как да използвате изкуствения интелигент във вашия бизнес. Статиите са кратки, приложими и насочени към реални резултати.
          </p>

          <div className="w-20 h-1 bg-gradient-to-r from-[#d4af37] to-[#f0d77c] mx-auto"></div>
        </div>
      </div>
    </section>
  );
};
