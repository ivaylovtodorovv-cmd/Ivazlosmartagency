import { MailIcon, MapPinIcon, PhoneIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";

const contactInfo = [
  {
    icon: PhoneIcon,
    text: "(987)-749-5403",
    href: null,
  },
  {
    icon: MailIcon,
    text: "info@conscellence.com",
    href: "mailto:info@consultingexcellence.com",
  },
  {
    icon: MapPinIcon,
    text: "123 Business Road, Suite 456, City, State, ZIP Code",
    href: null,
  },
];

export const ContactUsWrapperSection = (): JSX.Element => {
  return (
    <section className="flex flex-col lg:flex-row items-start gap-[33.44px] pt-[33.44px] pb-[50.17px] px-[50.17px] w-full bg-slate-500">
      <div className="flex flex-col items-start justify-center gap-[33.44px] pl-0 pr-[33.44px] py-0 flex-1 backdrop-blur-[10.45px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10.45px)_brightness(100%)]">
        <div className="flex flex-col items-start gap-[16.72px] w-full">
          <div className="flex flex-col items-start justify-center w-full">
            <div className="flex items-center gap-[10.03px] w-full">
              <img
                className="w-[33.44px] h-[33.44px]"
                alt="Icons arrow right"
                src="/icons-arrow-right-alt-2.svg"
              />

              <h2 className="text-[26.8px] leading-[29.4px] flex-1 [font-family:'Unbounded',Helvetica] font-normal text-white tracking-[0]">
                CONTACT
              </h2>
            </div>

            <h2 className="w-full [font-family:'Unbounded',Helvetica] font-normal text-white text-[26.8px] tracking-[0] leading-[29.4px]">
              US TODAY
            </h2>
          </div>

          <div className="flex items-start justify-center gap-[4.18px] pl-[33.44px] pr-0 py-0 w-full">
            <p className="flex-1 mt-[-0.42px] [font-family:'Montserrat',Helvetica] font-medium text-white text-[7.5px] tracking-[0] leading-[10.5px]">
              Contact us today to schedule a consultation and discover how we
              can help your business thrive.
            </p>
          </div>
        </div>

        <img
          className="flex-[0_0_auto]"
          alt="Frame"
          src="/frame-1000004987-1.svg"
        />
      </div>

      <div className="flex flex-col w-full lg:w-[212.37px] items-start gap-[50.17px]">
        <div className="flex flex-col items-start gap-[6.69px] w-full">
          <div className="flex items-center justify-center w-full mt-[-0.42px] [font-family:'Montserrat',Helvetica] font-bold text-white text-[8.4px] tracking-[0] leading-[12.5px]">
            Get a Free consultation
          </div>

          <div className="flex items-center gap-[3.34px] w-full">
            <div className="w-[122.07px] h-[23.41px] gap-[6.69px] px-[10.03px] py-[6.69px] rounded-[16.72px] flex items-center bg-white">
              <MailIcon className="w-[10.03px] h-[10.03px] text-slate-500" />

              <Input
                type="email"
                placeholder="Enter your email to get started"
                className="flex-1 h-auto border-0 p-0 [font-family:'Montserrat',Helvetica] font-medium text-slate-500 text-[5px] leading-[6.0px] placeholder:text-slate-500 focus-visible:ring-0 focus-visible:ring-offset-0"
              />
            </div>

            <Button className="inline-flex items-center gap-[6.69px] pl-[10.03px] pr-[3.34px] py-[2.51px] h-auto bg-[#0019ff] rounded-[33.44px] hover:bg-[#0019ff]/90">
              <span className="font-button-l font-[number:var(--button-l-font-weight)] text-white text-[length:var(--button-l-font-size)] tracking-[var(--button-l-letter-spacing)] leading-[var(--button-l-line-height)] whitespace-nowrap [font-style:var(--button-l-font-style)]">
                GET STARTED
              </span>

              <div className="gap-[3.34px] p-[5.02px] rounded-[33.44px] inline-flex flex-col items-start bg-slate-50">
                <img
                  className="w-[8.36px] h-[8.36px]"
                  alt="Icons arrow up right"
                  src="/icons-arrow-up-right-1.svg"
                />
              </div>
            </Button>
          </div>
        </div>

        <div className="inline-flex flex-col items-start justify-center gap-[6.69px]">
          {contactInfo.map((item, index) => {
            const IconComponent = item.icon;
            const content = (
              <>
                <IconComponent className="w-[16.72px] h-[16.72px] text-[#ececec]" />
                <span className="text-[6.7px] leading-[9.4px] flex items-center justify-center [font-family:'Montserrat',Helvetica] font-bold text-[#ececec] text-center tracking-[0] whitespace-nowrap">
                  {item.text}
                </span>
              </>
            );

            return item.href ? (
              <a
                key={index}
                href={item.href}
                rel="noopener noreferrer"
                target="_blank"
                className="inline-flex items-center gap-[6.69px]"
              >
                {content}
              </a>
            ) : (
              <div
                key={index}
                className="inline-flex items-center gap-[6.69px]"
              >
                {content}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
