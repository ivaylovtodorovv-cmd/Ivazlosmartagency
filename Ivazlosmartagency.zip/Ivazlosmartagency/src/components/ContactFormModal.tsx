import React, { useState } from 'react';
import { Modal } from './ui/modal';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Calendar, Clock } from 'lucide-react';

interface ContactFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  source: 'hero' | 'footer';
}

export const ContactFormModal: React.FC<ContactFormModalProps> = ({
  isOpen,
  onClose,
  source,
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    businessName: '',
    website: '',
    businessDescription: '',
    selectedDate: '',
    selectedTime: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '17:30',
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const datetime = `${formData.selectedDate} ${formData.selectedTime}`;
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          access_key: '86e179ce-62b3-4c77-b15b-2a0463be4da9',
          subject: `Нова заявка за консултация от ${formData.fullName}`,
          from_name: formData.fullName,
          name: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          business_name: formData.businessName,
          website: formData.website,
          business_description: formData.businessDescription,
          datetime: datetime,
          source: source === 'hero' ? 'Hero секция' : 'Footer секция',
          page_url: window.location.href,
        }),
      });

      if (response.ok) {
        setShowSuccess(true);
        setFormData({
          fullName: '',
          email: '',
          phone: '',
          businessName: '',
          website: '',
          businessDescription: '',
          selectedDate: '',
          selectedTime: '',
        });

        setTimeout(() => {
          setShowSuccess(false);
          onClose();
        }, 3000);
      }
    } catch (error) {
      console.error('Form submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setShowSuccess(false);
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        businessName: '',
        website: '',
        businessDescription: '',
        selectedDate: '',
        selectedTime: '',
      });
      onClose();
    }
  };

  const getTodayDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose}>
      <Card className="bg-white p-8 md:p-12 rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {!showSuccess ? (
          <>
            <div className="mb-10">
              <h2 className="text-3xl md:text-4xl font-bold text-[#222222] mb-4">
                Запишете безплатна консултация
              </h2>
              <p className="text-gray-600 text-lg leading-relaxed">
                Попълнете формата и ще се свържем с Вас за 30-минутна консултация
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Лични данни */}
              <div className="space-y-5">
                <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                  Лични данни
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="fullName" className="block text-base font-medium text-[#222222] mb-2">
                      Име и фамилия *
                    </label>
                    <Input
                      type="text"
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleChange}
                      required
                      placeholder="Иван Иванов"
                      className="w-full h-14 text-base text-[#222222] border-2 border-gray-300 rounded-lg px-4 focus:border-[#d4af37] focus:ring-2 focus:ring-[#d4af37]/20"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-base font-medium text-[#222222] mb-2">
                      Имейл *
                    </label>
                    <Input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      placeholder="ivan@example.com"
                      className="w-full h-14 text-base text-[#222222] border-2 border-gray-300 rounded-lg px-4 focus:border-[#d4af37] focus:ring-2 focus:ring-[#d4af37]/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="phone" className="block text-base font-medium text-[#222222] mb-2">
                      Телефон *
                    </label>
                    <Input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      placeholder="+359 888 123 456"
                      className="w-full h-14 text-base text-[#222222] border-2 border-gray-300 rounded-lg px-4 focus:border-[#d4af37] focus:ring-2 focus:ring-[#d4af37]/20"
                    />
                  </div>

                  <div>
                    <label htmlFor="website" className="block text-base font-medium text-[#222222] mb-2">
                      Уебсайт (ако има)
                    </label>
                    <Input
                      type="url"
                      id="website"
                      name="website"
                      value={formData.website}
                      onChange={handleChange}
                      placeholder="https://example.com"
                      className="w-full h-14 text-base text-[#222222] border-2 border-gray-300 rounded-lg px-4 focus:border-[#d4af37] focus:ring-2 focus:ring-[#d4af37]/20"
                    />
                  </div>
                </div>
              </div>

              {/* Бизнес информация */}
              <div className="space-y-5">
                <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                  Бизнес информация
                </h3>
                <div>
                  <label htmlFor="businessName" className="block text-base font-medium text-[#222222] mb-2">
                    Име на бизнеса *
                  </label>
                  <Input
                    type="text"
                    id="businessName"
                    name="businessName"
                    value={formData.businessName}
                    onChange={handleChange}
                    required
                    placeholder="Моята фирма ООД"
                    className="w-full h-14 text-base text-[#222222] border-2 border-gray-300 rounded-lg px-4 focus:border-[#d4af37] focus:ring-2 focus:ring-[#d4af37]/20"
                  />
                </div>

                <div>
                  <label htmlFor="businessDescription" className="block text-base font-medium text-[#222222] mb-2">
                    Кратко опишете бизнеса и предизвикателството *
                  </label>
                  <textarea
                    id="businessDescription"
                    name="businessDescription"
                    value={formData.businessDescription}
                    onChange={handleChange}
                    required
                    placeholder="Например: Малка счетоводна фирма с 5 служители. Искаме да автоматизираме обработката на фактури и комуникацията с клиенти."
                    className="w-full min-h-[120px] px-4 py-3 text-base text-[#222222] border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#d4af37]/20 focus:border-[#d4af37] resize-none"
                    rows={4}
                  />
                </div>
              </div>

              {/* Предпочитано време */}
              <div className="space-y-5">
                <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                  Предпочитано време за консултация
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="selectedDate" className="block text-base font-medium text-[#222222] mb-2">
                      <Calendar className="inline w-5 h-5 mr-1 text-[#d4af37]" />
                      Изберете дата *
                    </label>
                    <Input
                      type="date"
                      id="selectedDate"
                      name="selectedDate"
                      value={formData.selectedDate}
                      onChange={handleChange}
                      required
                      min={getTodayDate()}
                      className="w-full h-14 text-base text-[#222222] border-2 border-gray-300 rounded-lg px-4 focus:border-[#d4af37] focus:ring-2 focus:ring-[#d4af37]/20"
                    />
                  </div>

                  <div>
                    <label htmlFor="selectedTime" className="block text-base font-medium text-[#222222] mb-2">
                      <Clock className="inline w-5 h-5 mr-1 text-[#d4af37]" />
                      Изберете час *
                    </label>
                    <select
                      id="selectedTime"
                      name="selectedTime"
                      value={formData.selectedTime}
                      onChange={handleChange}
                      required
                      className="w-full h-14 px-4 text-base text-[#222222] border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#d4af37]/20 focus:border-[#d4af37] bg-white"
                    >
                      <option value="">Изберете час</option>
                      {timeSlots.map((time) => (
                        <option key={time} value={time}>
                          {time}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {formData.selectedDate && formData.selectedTime && (
                  <div className="bg-[#d4af37]/10 border-2 border-[#d4af37]/30 rounded-lg p-5">
                    <p className="text-base text-[#222222]">
                      <strong className="text-[#d4af37]">Избрана дата и час:</strong>{' '}
                      {new Date(formData.selectedDate).toLocaleDateString('bg-BG', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}{' '}
                      в {formData.selectedTime}
                    </p>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-[#E2C469] hover:bg-[#d4af37] text-[#1a3a52] font-bold py-5 text-lg rounded-xl transition-all duration-300 hover:scale-[1.02] shadow-lg hover:shadow-xl"
                >
                  {isSubmitting ? 'Изпращане...' : 'Изпрати заявката'}
                </Button>
                <Button
                  type="button"
                  onClick={handleClose}
                  disabled={isSubmitting}
                  variant="outline"
                  className="px-10 py-5 border-2 border-gray-300 text-gray-700 font-semibold text-lg rounded-xl hover:bg-gray-50 transition-colors"
                >
                  Отказ
                </Button>
              </div>
            </form>
          </>
        ) : (
          <div className="text-center py-12">
            <div className="mb-6 text-7xl">🎉</div>
            <h3 className="text-3xl font-bold text-gray-900 mb-3">
              Благодарим за доверието!
            </h3>
            <p className="text-gray-600 text-xl">
              Ще се свържем с Вас скоро!
            </p>
          </div>
        )}
      </Card>
    </Modal>
  );
};
