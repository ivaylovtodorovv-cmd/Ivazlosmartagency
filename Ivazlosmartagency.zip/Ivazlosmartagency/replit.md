# Ivaylo's Smart Agency - AI Business Solutions Website

## Overview
This is a modern React + TypeScript website for Ivaylo's Smart Agency, showcasing AI solutions for small and medium businesses. The site is built with Vite, React, and Tailwind CSS, featuring a professional landing page with lead capture functionality.

**Current State**: Fully functional and deployed on Replit. The website includes:
- Hero section with email capture
- Services, About Us, Features, and Testimonials sections
- Contact form with Supabase integration
- Email notifications via Resend API
- Responsive design with Tailwind CSS
- Bulgarian language content

## Project Architecture

### Tech Stack
- **Frontend Framework**: React 18.2.0 with TypeScript
- **Build Tool**: Vite 6.0.4
- **Styling**: Tailwind CSS 3.4.16 with tailwindcss-animate
- **UI Components**: Custom components with Radix UI primitives
- **Icons**: Lucide React
- **Backend**: Supabase (PostgreSQL database + Edge Functions)
- **Email Service**: Resend API

### Project Structure
```
├── src/
│   ├── components/
│   │   ├── ui/           # Reusable UI components (buttons, cards, inputs, etc.)
│   │   └── ContactFormModal.tsx
│   ├── hooks/            # Custom React hooks for lead handling
│   ├── lib/              # Utility functions and lead submission logic
│   ├── screens/
│   │   └── Cover/        # Main landing page with all sections
│   └── index.tsx         # Application entry point
├── public/               # Static assets (images, backgrounds)
├── index.html           # HTML template
├── vite.config.ts       # Vite configuration (port 5000, HMR setup)
└── tailwind.config.js   # Tailwind CSS configuration
```

### Key Features
1. **Lead Capture System**: Three CTA buttons collect email addresses:
   - Hero section "Започнете сега" button
   - Services section "Запишете разговор" button
   - Footer contact form

2. **Supabase Integration**:
   - PostgreSQL database with `leads` table
   - Edge function for sending email notifications
   - Environment variables: VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY

3. **Responsive Design**: Mobile-first approach with Tailwind CSS

## Recent Changes
- **2025-11-09**: Design improvements and mobile optimization
  - Removed broken images (brain.png from header/footer, isolation-mode.svg, decorative graphics)
  - Added brain pattern background across all main sections (350px tiles, 70% overlay opacity)
  - Improved mobile responsiveness for CTA buttons:
    - "Запази безплатна консултация" buttons now wrap text properly on mobile
    - "ИЗИСКАЙ КОНСУЛТАЦИЯ" button optimized for smaller screens
    - Reduced padding and font sizes on mobile while maintaining desktop appearance
  - Simplified FooterWrapperSection layout
  - Background pattern visible behind all content sections except header and footer

- **2025-11-09**: Initial setup in Replit environment
  - Configured Vite to run on port 5000 with 0.0.0.0 host
  - Added HMR configuration for Replit proxy
  - Installed Node.js 20 and all dependencies
  - Set up development workflow
  - Configured deployment for autoscale with build process
  - Added TypeScript type definitions for Vite environment

## Replit Configuration

### Development
- **Port**: 5000 (configured in vite.config.ts)
- **Host**: 0.0.0.0 (allows Replit proxy access)
- **Workflow**: `npm run dev` starts the development server
- **HMR**: Configured for WebSocket over wss://443

### Deployment
- **Type**: Autoscale (stateless deployment)
- **Build**: `npm run build` (generates optimized production build)
- **Run**: `npx vite preview` (serves production build)

### Environment Variables
Required environment variables in `.env`:
```
VITE_SUPABASE_URL=https://lwolcbbrkvqftqvdvwox.supabase.co
VITE_SUPABASE_ANON_KEY=[key provided]
```

## Development Workflow

### Running Locally
1. Dependencies are already installed
2. Development server runs automatically via workflow
3. Access the site through Replit's webview

### Making Changes
- Edit files in `src/` directory
- Vite's HMR will hot-reload changes
- Check browser console for any errors

### Testing Lead Capture
1. Test hero section email form
2. Test services CTA (scrolls to footer)
3. Test footer contact form
4. Verify toast notifications appear
5. Check Supabase database for new leads

## User Preferences
None configured yet.

## Notes
- The site is in Bulgarian language
- Supabase is already configured with a deployed edge function
- Email notifications are sent to: ivaylosmartagency@gmail.com
- The design uses Playfair Display and Montserrat fonts from Google Fonts
